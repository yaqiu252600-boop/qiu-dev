# DroidLink 打包说明

## Windows EXE

需要 Python 3.12。安装依赖后执行：

```powershell
python -m pip install -r requirements.txt
python -m PyInstaller --noconfirm --clean --onefile --noconsole --name DroidLink --paths src --collect-all tkinterdnd2 droidlink_launcher.py
```

生成文件位于 `dist/DroidLink.exe`。正式发布建议购买代码签名证书并对 EXE 签名。

## Android APK

需要 JDK 17、Android SDK Platform 35、Build Tools 35.0.0 和 Gradle 8.9。

在 `android/local.properties` 中设置本机 SDK 路径：

```properties
sdk.dir=C:/path/to/android-sdk
```

构建可安装的调试 APK：

```powershell
cd android
gradle --no-daemon assembleDebug
```

输出路径：`android/app/build/outputs/apk/debug/app-debug.apk`。

当前交付 APK 使用 Android 调试签名，适合本地测试。正式发布前应创建专用发布密钥，妥善保存并执行签名发布构建。
