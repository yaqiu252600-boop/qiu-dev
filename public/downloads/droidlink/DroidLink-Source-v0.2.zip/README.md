# DroidLink

DroidLink 是一个 Android 手机与 Windows 电脑之间的本地互联工具。当前 V0.2 在保留原有 Windows 文件互传、二维码、6 位配对码和本地 HTTP 服务的基础上，新增了原生 Android App，并完善了文件互传闭环。

## 当前已完成

- Windows 10/11 单文件程序
- Android 10 及以上原生 APK
- 二维码或手动地址 + 6 位一次性配对码
- 手机端“仅本次允许 / 信任此电脑”授权确认
- 电脑向手机发送文件，手机向电脑批量发送文件
- 大文件流式传输、进度、速度、剩余时间、取消和失败提示
- Windows 文件和文件夹拖拽；文件夹自动压缩为 ZIP
- 传输状态、传输历史、重复文件自动重命名
- 接收目录与传输历史持久化
- 手机端主动断开、Windows 端主动断开
- 全程局域网直传，不经过云端

## 尚未完成

以下功能按开发文档顺序留到后续阶段：USB/蓝牙连接、手机投屏、鼠标键盘控制、剪贴板同步、手机文件管理和完整设置中心。

## 安装

### Windows

直接双击 `DroidLink.exe`。首次运行时，Windows 防火墙可能询问网络权限，请只允许“专用网络”。

### Android

把 `DroidLink-Android-v0.2.apk` 传到 Android 手机并安装。APK 是本地调试签名版本，手机可能要求允许“安装未知应用”。建议 Android 10 或更高版本。

## 连接和传文件

1. 让手机和电脑连接同一个 Wi-Fi。
2. 打开 Windows 端，确认显示“服务已启动”。
3. 打开 Android App，点击“扫描二维码”；也可以手动输入电脑地址与 6 位配对码。
4. 在手机授权框选择“仅本次允许”或“信任此电脑”。
5. 手机发电脑：点击“选择手机文件”。
6. 电脑发手机：在 Windows 端选择或拖入文件，然后在 Android App 中刷新并下载。

手机下载默认保存到 `Download/DroidLink/`；电脑接收目录默认为当前 Windows 用户的 `Downloads\DroidLink`，可在界面修改。

## 开发运行

Windows 端：

```powershell
python -m pip install -r requirements.txt
$env:PYTHONPATH = "$PWD\src"
python -m droidlink.main
python -m unittest discover -s tests -v
```

Android 端使用 Gradle 构建，详见 `docs/BUILD.md`。

## 安全

- 文件仅通过当前局域网传输。
- 配对码只能成功使用一次，连接后使用随机会话令牌。
- 未配对设备无法读取文件列表、上传或下载。
- 两端均可主动撤销当前连接。
- 不包含账号、云盘或公网远程访问。
