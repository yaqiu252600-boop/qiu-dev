package com.droidlink.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private static final int PICK_FILES = 1001;
    private static final int BLUE = Color.rgb(37, 99, 235);
    private static final int INK = Color.rgb(23, 32, 51);
    private static final int MUTED = Color.rgb(100, 116, 139);
    private static final int BG = Color.rgb(244, 247, 251);

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean cancelUpload = new AtomicBoolean(false);
    private SharedPreferences preferences;
    private String baseUrl = "";
    private String token = "";
    private String currentComputer = "";

    private EditText hostInput;
    private EditText codeInput;
    private TextView statusText;
    private TextView connectionDetail;
    private TextView progressText;
    private ProgressBar uploadProgress;
    private LinearLayout connectedArea;
    private LinearLayout filesArea;
    private LinearLayout historyArea;
    private Button connectButton;
    private Button disconnectButton;
    private Button cancelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = getSharedPreferences("droidlink", MODE_PRIVATE);
        baseUrl = preferences.getString("base_url", "");
        token = preferences.getString("token", "");
        buildUi();
        if (!baseUrl.isEmpty()) hostInput.setText(baseUrl);
        if (!token.isEmpty()) validateSession();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable background(int color, int radius, Integer strokeColor) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        if (strokeColor != null) drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button button(String label, boolean primary) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(14);
        button.setTextColor(primary ? Color.WHITE : BLUE);
        button.setAllCaps(false);
        button.setBackground(background(primary ? BLUE : Color.rgb(239, 246, 255), 12, null));
        button.setPadding(dp(14), dp(8), dp(14), dp(8));
        return button;
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(17), dp(18), dp(17));
        card.setBackground(background(Color.WHITE, 18, Color.rgb(226, 232, 240)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, dp(14));
        card.setLayoutParams(params);
        return card;
    }

    private void buildUi() {
        getWindow().setStatusBarColor(Color.rgb(29, 78, 216));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(22), dp(16), dp(40));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(text("DroidLink", 27, INK, true));
        TextView subtitle = text("Android ↔ Windows 本地互联", 14, MUTED, false);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        subtitleParams.setMargins(0, dp(4), 0, dp(18));
        root.addView(subtitle, subtitleParams);

        LinearLayout statusCard = card();
        statusText = text("● 未连接", 15, MUTED, true);
        connectionDetail = text("请扫描电脑端二维码或输入连接地址", 13, MUTED, false);
        statusCard.addView(statusText);
        LinearLayout.LayoutParams detailParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        detailParams.setMargins(0, dp(5), 0, 0);
        statusCard.addView(connectionDetail, detailParams);
        root.addView(statusCard);

        LinearLayout connectCard = card();
        connectCard.addView(text("连接电脑", 18, INK, true));
        hostInput = new EditText(this);
        hostInput.setHint("例如 http://192.168.1.8:8765");
        hostInput.setSingleLine(true);
        hostInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        styleInput(hostInput);
        connectCard.addView(hostInput, fieldParams());
        codeInput = new EditText(this);
        codeInput.setHint("6 位配对码");
        codeInput.setSingleLine(true);
        codeInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        styleInput(codeInput);
        connectCard.addView(codeInput, fieldParams());

        LinearLayout connectButtons = new LinearLayout(this);
        connectButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button scanButton = button("扫描二维码", false);
        scanButton.setOnClickListener(v -> scanQr());
        connectButton = button("连接", true);
        connectButton.setOnClickListener(v -> startPairing());
        connectButtons.addView(scanButton, weightedButtonParams(1f, dp(5)));
        connectButtons.addView(connectButton, weightedButtonParams(1f, 0));
        connectCard.addView(connectButtons, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(connectCard);

        connectedArea = new LinearLayout(this);
        connectedArea.setOrientation(LinearLayout.VERTICAL);

        LinearLayout sendCard = card();
        sendCard.addView(text("发送到电脑", 18, INK, true));
        TextView sendHint = text("支持图片、视频、文档、APK 和其他普通文件，可多选。", 13, MUTED, false);
        sendCard.addView(sendHint, fieldParams());
        Button sendButton = button("选择手机文件", true);
        sendButton.setOnClickListener(v -> chooseFiles());
        sendCard.addView(sendButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        uploadProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        uploadProgress.setMax(100);
        uploadProgress.setVisibility(View.GONE);
        sendCard.addView(uploadProgress, fieldParams());
        progressText = text("", 12, MUTED, false);
        sendCard.addView(progressText);
        cancelButton = button("取消传输", false);
        cancelButton.setVisibility(View.GONE);
        cancelButton.setOnClickListener(v -> cancelUpload.set(true));
        sendCard.addView(cancelButton, fieldParams());
        connectedArea.addView(sendCard);

        LinearLayout receiveCard = card();
        LinearLayout receiveHeader = new LinearLayout(this);
        receiveHeader.setGravity(Gravity.CENTER_VERTICAL);
        receiveHeader.addView(text("电脑发来的文件", 18, INK, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button refreshButton = button("刷新", false);
        refreshButton.setOnClickListener(v -> refreshData());
        receiveHeader.addView(refreshButton);
        receiveCard.addView(receiveHeader);
        filesArea = new LinearLayout(this);
        filesArea.setOrientation(LinearLayout.VERTICAL);
        receiveCard.addView(filesArea, fieldParams());
        connectedArea.addView(receiveCard);

        LinearLayout historyCard = card();
        historyCard.addView(text("最近传输", 18, INK, true));
        historyArea = new LinearLayout(this);
        historyArea.setOrientation(LinearLayout.VERTICAL);
        historyCard.addView(historyArea, fieldParams());
        connectedArea.addView(historyCard);

        disconnectButton = button("断开与电脑的连接", false);
        disconnectButton.setOnClickListener(v -> disconnect());
        LinearLayout supportButtons = new LinearLayout(this);
        supportButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button permissionButton = button("权限说明", false);
        permissionButton.setOnClickListener(v -> showPermissionGuide());
        Button trustedButton = button("已信任设备", false);
        trustedButton.setOnClickListener(v -> showTrustedDevice());
        supportButtons.addView(permissionButton, weightedButtonParams(1f, 0));
        supportButtons.addView(trustedButton, weightedButtonParams(1f, dp(6)));
        connectedArea.addView(supportButtons, fieldParams());
        connectedArea.addView(disconnectButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        connectedArea.setVisibility(View.GONE);
        root.addView(connectedArea);

        TextView security = text("文件只在当前局域网中直传，不经过 DroidLink 云端。手机可随时主动断开。", 12, Color.rgb(15, 118, 110), false);
        LinearLayout.LayoutParams securityParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        securityParams.setMargins(dp(4), dp(4), dp(4), 0);
        root.addView(security, securityParams);
        setContentView(scroll);
    }

    private LinearLayout.LayoutParams fieldParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, dp(10), 0, dp(10));
        return params;
    }

    private LinearLayout.LayoutParams weightedButtonParams(float weight, int leftMargin) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        params.setMargins(leftMargin, 0, 0, 0);
        return params;
    }

    private void styleInput(EditText input) {
        input.setTextSize(15);
        input.setTextColor(INK);
        input.setHintTextColor(Color.rgb(148, 163, 184));
        input.setBackground(background(Color.WHITE, 12, Color.rgb(203, 213, 225)));
        input.setPadding(dp(13), dp(12), dp(13), dp(12));
    }

    private void scanQr() {
        GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                .enableAutoZoom()
                .build();
        GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(this, options);
        scanner.startScan()
                .addOnSuccessListener(barcode -> applyQrValue(barcode.getRawValue()))
                .addOnFailureListener(error -> showError("二维码扫描失败", error))
                .addOnCanceledListener(() -> toast("已取消扫描"));
    }

    private void applyQrValue(String raw) {
        if (raw == null || raw.isEmpty()) {
            toast("二维码内容为空");
            return;
        }
        try {
            Uri uri = Uri.parse(raw);
            String scheme = uri.getScheme();
            String authority = uri.getEncodedAuthority();
            String code = uri.getQueryParameter("code");
            if (scheme == null || authority == null) throw new IllegalArgumentException("二维码不是 DroidLink 地址");
            baseUrl = scheme + "://" + authority;
            hostInput.setText(baseUrl);
            if (code != null) codeInput.setText(code);
            toast("已读取电脑地址和配对码");
            startPairing();
        } catch (Exception error) {
            showError("无法识别二维码", error);
        }
    }

    private String normalizeBaseUrl(String value) throws Exception {
        String result = value.trim();
        if (!result.matches("^https?://.*")) result = "http://" + result;
        URL url = new URL(result);
        if (url.getHost().isEmpty()) throw new IllegalArgumentException("电脑地址无效");
        int port = url.getPort();
        return url.getProtocol() + "://" + url.getHost() + (port > 0 ? ":" + port : "");
    }

    private void startPairing() {
        String code = codeInput.getText().toString().trim();
        if (code.length() != 6) {
            toast("请输入 6 位配对码");
            return;
        }
        try {
            baseUrl = normalizeBaseUrl(hostInput.getText().toString());
        } catch (Exception error) {
            showError("电脑地址无效", error);
            return;
        }
        if (!hasNetwork()) {
            toast("当前没有可用网络，请先连接 Wi-Fi");
            return;
        }
        setBusy(true, "正在检查电脑连接…");
        executor.execute(() -> {
            try {
                JSONObject ping = requestJson("GET", baseUrl + "/api/ping", null, false);
                String computer = ping.optString("computer", "这台电脑");
                runOnUiThread(() -> showAuthorizationDialog(computer, code));
            } catch (Exception error) {
                runOnUiThread(() -> {
                    setBusy(false, "无法连接电脑");
                    showError("连接失败", error);
                });
            }
        });
    }

    private void showAuthorizationDialog(String computer, String code) {
        setBusy(false, "等待授权确认");
        new AlertDialog.Builder(this)
                .setTitle("允许连接这台电脑？")
                .setMessage("电脑名称：" + computer + "\n连接方式：Wi-Fi 局域网\n\n连接后，电脑可以向本机发送文件。")
                .setNegativeButton("拒绝", null)
                .setPositiveButton("仅本次允许", (dialog, which) -> performPair(code, false))
                .setNeutralButton("信任此电脑", (dialog, which) -> performPair(code, true))
                .show();
    }

    private void performPair(String code, boolean remember) {
        setBusy(true, "正在安全配对…");
        executor.execute(() -> {
            try {
                JSONObject request = new JSONObject();
                request.put("code", code);
                request.put("device", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL);
                JSONObject response = requestJson("POST", baseUrl + "/api/pair", request, false);
                token = response.getString("token");
                String computer = response.optString("computer", "电脑");
                String connection = response.optString("connection", "Wi-Fi 局域网");
                SharedPreferences.Editor editor = preferences.edit().putString("base_url", baseUrl);
                if (remember) editor.putString("token", token).putString("trusted_computer", computer);
                else editor.remove("token").remove("trusted_computer");
                editor.apply();
                runOnUiThread(() -> {
                    showConnected(computer, connection);
                    refreshData();
                    toast("连接成功");
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    clearSession();
                    setBusy(false, "配对失败");
                    showError("配对失败", error);
                });
            }
        });
    }

    private void validateSession() {
        executor.execute(() -> {
            try {
                JSONObject session = requestJson("GET", baseUrl + "/api/session", null, true);
                runOnUiThread(() -> {
                    showConnected(session.optString("computer", "电脑"), session.optString("connection", "Wi-Fi 局域网"));
                    refreshData();
                });
            } catch (Exception error) {
                runOnUiThread(this::clearSession);
            }
        });
    }

    private void showConnected(String computer, String connection) {
        currentComputer = computer;
        statusText.setText("● 已连接");
        statusText.setTextColor(Color.rgb(15, 159, 110));
        connectionDetail.setText(String.format(Locale.CHINA, "%s · %s", computer, connection));
        connectedArea.setVisibility(View.VISIBLE);
        connectButton.setEnabled(true);
    }

    private void setBusy(boolean busy, String message) {
        connectButton.setEnabled(!busy);
        connectionDetail.setText(message);
    }

    private void chooseFiles() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_FILES);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILES || resultCode != RESULT_OK || data == null) return;
        List<Uri> uris = new ArrayList<>();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        if (!uris.isEmpty()) uploadFiles(uris);
    }

    private void uploadFiles(List<Uri> uris) {
        cancelUpload.set(false);
        uploadProgress.setVisibility(View.VISIBLE);
        cancelButton.setVisibility(View.VISIBLE);
        executor.execute(() -> {
            int completed = 0;
            try {
                for (Uri uri : uris) {
                    if (cancelUpload.get()) throw new IOException("传输已取消");
                    PreparedUpload file = prepareUpload(uri);
                    uploadOne(file, completed + 1, uris.size());
                    completed++;
                    file.deleteTemporary();
                }
                int total = completed;
                runOnUiThread(() -> {
                    uploadProgress.setProgress(100);
                    progressText.setText(String.format(Locale.CHINA, "已成功发送 %d 个文件", total));
                    cancelButton.setVisibility(View.GONE);
                    toast("文件已发送到电脑");
                    refreshData();
                });
            } catch (Exception error) {
                int done = completed;
                runOnUiThread(() -> {
                    cancelButton.setVisibility(View.GONE);
                    progressText.setText(String.format(Locale.CHINA, "已完成 %d/%d，%s", done, uris.size(), readableError(error)));
                    showError("文件发送未完成", error);
                });
            }
        });
    }

    private PreparedUpload prepareUpload(Uri uri) throws IOException {
        String name = "未命名文件";
        long size = -1;
        try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (nameIndex >= 0) name = cursor.getString(nameIndex);
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex);
            }
        }
        if (size >= 0) return new PreparedUpload(uri, name, size, null);
        File temporary = new File(getCacheDir(), "upload-" + System.currentTimeMillis());
        try (InputStream input = getContentResolver().openInputStream(uri); OutputStream output = new FileOutputStream(temporary)) {
            if (input == null) throw new IOException("无法读取文件");
            byte[] buffer = new byte[1024 * 1024];
            int count;
            while ((count = input.read(buffer)) >= 0) output.write(buffer, 0, count);
        }
        return new PreparedUpload(uri, name, temporary.length(), temporary);
    }

    private void uploadOne(PreparedUpload file, int index, int total) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(baseUrl + "/api/upload").openConnection();
        connection.setConnectTimeout(10_000);
        connection.setReadTimeout(60_000);
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setRequestProperty("Authorization", "Bearer " + token);
        connection.setRequestProperty("X-File-Name", URLEncoder.encode(file.name, "UTF-8"));
        connection.setFixedLengthStreamingMode(file.size);
        long started = System.currentTimeMillis();
        long sent = 0;
        try (InputStream input = file.open(this); OutputStream output = new BufferedOutputStream(connection.getOutputStream())) {
            byte[] buffer = new byte[1024 * 1024];
            int count;
            while ((count = input.read(buffer)) >= 0) {
                if (cancelUpload.get()) {
                    connection.disconnect();
                    throw new IOException("传输已取消");
                }
                output.write(buffer, 0, count);
                sent += count;
                long currentSent = sent;
                long elapsed = Math.max(System.currentTimeMillis() - started, 1);
                double speed = currentSent * 1000.0 / elapsed;
                int percent = file.size == 0 ? 100 : (int) Math.min(100, currentSent * 100 / file.size);
                double eta = speed > 0 ? (file.size - currentSent) / speed : 0;
                runOnUiThread(() -> {
                    uploadProgress.setProgress(percent);
                    progressText.setText(String.format(Locale.CHINA, "%d/%d  %s  %d%% · %s/s · 剩余 %d 秒", index, total, file.name, percent, humanSize((long) speed), Math.max(0, Math.round(eta))));
                });
            }
        }
        int status = connection.getResponseCode();
        String response = readResponse(connection, status);
        connection.disconnect();
        if (status < 200 || status >= 300) throw new ApiException(messageFromResponse(response, status));
    }

    private void refreshData() {
        if (token.isEmpty()) return;
        executor.execute(() -> {
            try {
                JSONObject files = requestJson("GET", baseUrl + "/api/files", null, true);
                JSONObject history = requestJson("GET", baseUrl + "/api/history", null, true);
                runOnUiThread(() -> {
                    renderFiles(files.optJSONArray("files"));
                    renderHistory(history.optJSONArray("history"));
                });
            } catch (Exception error) {
                runOnUiThread(() -> showError("刷新失败", error));
            }
        });
    }

    private void renderFiles(JSONArray files) {
        filesArea.removeAllViews();
        if (files == null || files.length() == 0) {
            filesArea.addView(text("电脑端暂时没有待接收文件", 13, MUTED, false));
            return;
        }
        for (int i = 0; i < files.length(); i++) {
            JSONObject item = files.optJSONObject(i);
            if (item == null) continue;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(10), 0, dp(10));
            LinearLayout labels = new LinearLayout(this);
            labels.setOrientation(LinearLayout.VERTICAL);
            labels.addView(text(item.optString("name", "文件"), 14, INK, true));
            labels.addView(text(humanSize(item.optLong("size")) + " · " + item.optString("status", "等待下载"), 12, MUTED, false));
            row.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            Button download = button("下载", false);
            String id = item.optString("id");
            String name = item.optString("name", "DroidLink-file");
            download.setOnClickListener(v -> enqueueDownload(id, name));
            row.addView(download);
            filesArea.addView(row);
        }
    }

    private void renderHistory(JSONArray history) {
        historyArea.removeAllViews();
        if (history == null || history.length() == 0) {
            historyArea.addView(text("暂无传输记录", 13, MUTED, false));
            return;
        }
        for (int i = 0; i < Math.min(8, history.length()); i++) {
            JSONObject item = history.optJSONObject(i);
            if (item == null) continue;
            String line = item.optString("direction") + " · " + item.optString("name") + " · " + humanSize(item.optLong("size"));
            TextView title = text(line, 13, INK, false);
            TextView detail = text(item.optString("time") + " · " + item.optString("status", "成功"), 11, MUTED, false);
            LinearLayout block = new LinearLayout(this);
            block.setOrientation(LinearLayout.VERTICAL);
            block.setPadding(0, dp(8), 0, dp(8));
            block.addView(title);
            block.addView(detail);
            historyArea.addView(block);
        }
    }

    private void enqueueDownload(String id, String name) {
        try {
            String url = baseUrl + "/api/download/" + id + "?token=" + URLEncoder.encode(token, "UTF-8");
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(name);
            request.setDescription("DroidLink 正在从电脑接收文件");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "DroidLink/" + safeDownloadName(name));
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            manager.enqueue(request);
            toast("已开始下载到 Download/DroidLink");
        } catch (Exception error) {
            showError("下载启动失败", error);
        }
    }

    private String safeDownloadName(String name) {
        String cleaned = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        return System.currentTimeMillis() + "-" + cleaned;
    }

    private void disconnect() {
        if (token.isEmpty()) return;
        executor.execute(() -> {
            try {
                requestJson("POST", baseUrl + "/api/disconnect", new JSONObject(), true);
            } catch (Exception ignored) {
            }
            runOnUiThread(() -> {
                clearSession();
                toast("已断开连接");
            });
        });
    }

    private void showPermissionGuide() {
        new AlertDialog.Builder(this)
                .setTitle("DroidLink 权限说明")
                .setMessage("当前文件互传版本使用：\n\n• 网络访问：连接同一 Wi-Fi 下的电脑\n• 系统文件选择器：由你主动选择要发送的文件\n• 下载管理器：把电脑文件保存到 Download/DroidLink\n\nDroidLink 不会扫描全部手机文件，也不会把文件上传到云端。后续投屏和控制功能会在使用时单独申请屏幕录制与无障碍权限。")
                .setPositiveButton("知道了", null)
                .show();
    }

    private void showTrustedDevice() {
        String trusted = preferences.getString("trusted_computer", "");
        String message = trusted.isEmpty() ? "当前没有长期信任的电脑。\n\n本次连接会在 App 或电脑服务关闭后失效。" : "已信任：" + trusted + "\n地址：" + baseUrl;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("已信任设备")
                .setMessage(message)
                .setNegativeButton("关闭", null)
                .setPositiveButton(trusted.isEmpty() ? "知道了" : "移除信任", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (!trusted.isEmpty()) {
                preferences.edit().remove("token").remove("trusted_computer").apply();
                toast("已移除对 " + trusted + " 的信任");
                dialog.dismiss();
            } else {
                dialog.dismiss();
            }
        }));
        dialog.show();
    }

    private void clearSession() {
        token = "";
        currentComputer = "";
        preferences.edit().remove("token").apply();
        statusText.setText("● 未连接");
        statusText.setTextColor(MUTED);
        connectionDetail.setText("请扫描电脑端二维码或输入连接地址");
        connectedArea.setVisibility(View.GONE);
        connectButton.setEnabled(true);
    }

    private JSONObject requestJson(String method, String absoluteUrl, JSONObject body, boolean authorized) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(absoluteUrl).openConnection();
        connection.setConnectTimeout(8_000);
        connection.setReadTimeout(15_000);
        connection.setRequestMethod(method);
        connection.setRequestProperty("Accept", "application/json");
        if (authorized && !token.isEmpty()) connection.setRequestProperty("Authorization", "Bearer " + token);
        if (body != null) {
            byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setFixedLengthStreamingMode(payload.length);
            try (OutputStream output = connection.getOutputStream()) {
                output.write(payload);
            }
        }
        int status = connection.getResponseCode();
        String response = readResponse(connection, status);
        connection.disconnect();
        if (status < 200 || status >= 300) throw new ApiException(messageFromResponse(response, status));
        return response.isEmpty() ? new JSONObject() : new JSONObject(response);
    }

    private String readResponse(HttpURLConnection connection, int status) throws IOException {
        InputStream stream = status >= 200 && status < 400 ? connection.getInputStream() : connection.getErrorStream();
        if (stream == null) return "";
        try (InputStream input = new BufferedInputStream(stream); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) >= 0) output.write(buffer, 0, count);
            return new String(output.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private String messageFromResponse(String response, int status) {
        try {
            return new JSONObject(response).optString("error", "请求失败（" + status + "）");
        } catch (JSONException ignored) {
            return "请求失败（" + status + "）";
        }
    }

    private boolean hasNetwork() {
        ConnectivityManager manager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (manager == null || manager.getActiveNetwork() == null) return false;
        NetworkCapabilities capabilities = manager.getNetworkCapabilities(manager.getActiveNetwork());
        return capabilities != null && (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
    }

    private String humanSize(long value) {
        double size = value;
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int index = 0;
        while (size >= 1024 && index < units.length - 1) {
            size /= 1024;
            index++;
        }
        return index == 0 ? String.format(Locale.CHINA, "%.0f %s", size, units[index]) : String.format(Locale.CHINA, "%.1f %s", size, units[index]);
    }

    private String readableError(Throwable error) {
        String message = error.getMessage();
        return message == null || message.isEmpty() ? error.getClass().getSimpleName() : message;
    }

    private void showError(String title, Throwable error) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(readableError(error) + "\n\n请确认手机和电脑在同一 Wi-Fi，并检查 Windows 防火墙的专用网络权限。")
                .setPositiveButton("知道了", null)
                .show();
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        cancelUpload.set(true);
        executor.shutdownNow();
        super.onDestroy();
    }

    private static class ApiException extends IOException {
        ApiException(String message) {
            super(message);
        }
    }

    private static class PreparedUpload {
        final Uri uri;
        final String name;
        final long size;
        final File temporary;

        PreparedUpload(Uri uri, String name, long size, File temporary) {
            this.uri = uri;
            this.name = name;
            this.size = size;
            this.temporary = temporary;
        }

        InputStream open(Context context) throws IOException {
            if (temporary != null) return new FileInputStream(temporary);
            InputStream stream = context.getContentResolver().openInputStream(uri);
            if (stream == null) throw new IOException("无法读取文件");
            return stream;
        }

        void deleteTemporary() {
            if (temporary != null) temporary.delete();
        }
    }
}
