from __future__ import annotations

import http.client
import json
import tempfile
import time
import unittest
import urllib.parse
from pathlib import Path

from droidlink.core import AppState, safe_filename, start_server, unique_path


class TransferTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        self.state = AppState(root / "received", root / "data")
        self.server, _ = start_server(self.state, first_port=18865)
        self.port = self.server.server_port

    def tearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.temp.cleanup()

    def request(self, method: str, path: str, body: bytes = b"", headers: dict[str, str] | None = None):
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        connection.request(method, path, body=body, headers=headers or {})
        response = connection.getresponse()
        payload = response.read()
        connection.close()
        return response.status, response.getheaders(), payload

    def pair(self) -> str:
        payload = json.dumps({"code": self.state.pairing_code, "device": "测试手机"}).encode()
        status, _, body = self.request("POST", "/api/pair", payload, {"Content-Type": "application/json", "Content-Length": str(len(payload))})
        self.assertEqual(status, 200)
        return json.loads(body)["token"]

    def test_pair_session_upload_and_persistent_history(self) -> None:
        token = self.pair()
        status, _, body = self.request("GET", "/api/session", headers={"Authorization": f"Bearer {token}"})
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["device"], "测试手机")

        content = "来自手机".encode("utf-8")
        status, _, body = self.request("POST", "/api/upload", content, {"Authorization": f"Bearer {token}", "Content-Length": str(len(content)), "X-File-Name": urllib.parse.quote("测试.txt")})
        self.assertEqual(status, 200, body)
        self.assertEqual((Path(self.temp.name) / "received" / "测试.txt").read_bytes(), content)
        self.assertTrue((Path(self.temp.name) / "data" / "history.json").is_file())
        self.assertEqual(self.state.history[0].direction, "手机 → 电脑")
        self.assertEqual(self.state.history[0].status, "成功")

    def test_share_download_updates_status(self) -> None:
        token = self.pair()
        source = Path(self.temp.name) / "computer.bin"
        source.write_bytes(b"abc123")
        item = self.state.add_shared([source])[0]
        status, headers, body = self.request("GET", f"/api/download/{item.id}?token={urllib.parse.quote(token)}")
        self.assertEqual(status, 200)
        self.assertEqual(body, b"abc123")
        self.assertTrue(any(name.lower() == "content-disposition" for name, _ in headers))
        public = self.state.list_shared()[0]
        for _ in range(20):
            if public["status"] == "已发送到手机":
                break
            time.sleep(0.05)
            public = self.state.list_shared()[0]
        self.assertEqual(public["status"], "已发送到手机")
        self.assertEqual(public["downloads"], 1)

    def test_disconnect_revokes_token(self) -> None:
        token = self.pair()
        status, _, _ = self.request("POST", "/api/disconnect", headers={"Authorization": f"Bearer {token}", "Content-Length": "0"})
        self.assertEqual(status, 200)
        status, _, _ = self.request("GET", "/api/files", headers={"Authorization": f"Bearer {token}"})
        self.assertEqual(status, 401)

    def test_receive_directory_setting_is_persistent(self) -> None:
        root = Path(self.temp.name)
        changed = root / "changed"
        self.state.set_receive_dir(changed)
        restored = AppState(root / "fallback", root / "data")
        self.assertEqual(restored.receive_dir, changed)

    def test_unauthorized_requests_are_rejected(self) -> None:
        status, _, _ = self.request("GET", "/api/files")
        self.assertEqual(status, 401)

    def test_filename_safety_and_collision(self) -> None:
        folder = Path(self.temp.name)
        self.assertEqual(safe_filename("../../evil?.txt"), "evil.txt")
        (folder / "same.txt").write_text("x")
        self.assertEqual(unique_path(folder, "same.txt").name, "same (1).txt")


if __name__ == "__main__":
    unittest.main()
