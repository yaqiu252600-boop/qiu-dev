from __future__ import annotations

import json
import mimetypes
import os
import secrets
import socket
import threading
import urllib.parse
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Callable

from .mobile_page import mobile_page


MAX_UPLOAD_BYTES = 10 * 1024 * 1024 * 1024


def human_time() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def default_data_dir() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    return base / "DroidLink"


def safe_filename(value: str) -> str:
    name = Path(value.replace("\\", "/")).name
    name = "".join(ch for ch in name if ch >= " " and ch not in '<>:"/\\|?*').strip(" .")
    return name[:240] or "未命名文件"


def unique_path(folder: Path, name: str) -> Path:
    target = folder / safe_filename(name)
    if not target.exists():
        return target
    stem, suffix = target.stem, target.suffix
    for index in range(1, 10_000):
        candidate = folder / f"{stem} ({index}){suffix}"
        if not candidate.exists():
            return candidate
    raise RuntimeError("无法生成不重复的文件名")


def local_ipv4() -> str:
    candidates: list[str] = []
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("192.0.2.1", 80))
        candidates.append(sock.getsockname()[0])
        sock.close()
    except OSError:
        pass
    try:
        for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            candidates.append(item[4][0])
    except OSError:
        pass
    private = [ip for ip in candidates if ip.startswith(("192.168.", "10.", "172."))]
    return (private or [ip for ip in candidates if ip != "127.0.0.1"] or ["127.0.0.1"])[0]


@dataclass
class SharedFile:
    id: str
    name: str
    size: int
    path: str
    status: str = "等待手机下载"
    downloads: int = 0

    def public(self) -> dict[str, object]:
        return {
            "id": self.id,
            "name": self.name,
            "size": self.size,
            "status": self.status,
            "downloads": self.downloads,
        }


@dataclass(frozen=True)
class TransferRecord:
    name: str
    size: int
    direction: str
    time: str
    path: str
    status: str = "成功"
    error: str = ""


class AppState:
    def __init__(self, receive_dir: Path, data_dir: Path | None = None):
        self.data_dir = data_dir
        if self.data_dir:
            self.data_dir.mkdir(parents=True, exist_ok=True)
        configured = self._read_json("settings.json")
        saved_receive = configured.get("receive_dir") if isinstance(configured, dict) else None
        self.receive_dir = Path(saved_receive) if saved_receive else receive_dir
        self.receive_dir.mkdir(parents=True, exist_ok=True)
        self.pairing_code = self._new_code()
        self.shared: dict[str, SharedFile] = {}
        self.tokens: dict[str, str] = {}
        self.history: list[TransferRecord] = self._load_history()
        self.lock = threading.RLock()
        self.callback: Callable[[str], None] | None = None

    @staticmethod
    def _new_code() -> str:
        return f"{secrets.randbelow(900_000) + 100_000:06d}"

    def _read_json(self, name: str) -> object:
        if not self.data_dir:
            return {}
        path = self.data_dir / name
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}

    def _write_json(self, name: str, payload: object) -> None:
        if not self.data_dir:
            return
        path = self.data_dir / name
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(path)

    def _load_history(self) -> list[TransferRecord]:
        raw = self._read_json("history.json")
        if not isinstance(raw, list):
            return []
        records: list[TransferRecord] = []
        for item in raw[:100]:
            if not isinstance(item, dict):
                continue
            try:
                records.append(TransferRecord(**item))
            except TypeError:
                continue
        return records

    def _save_history(self) -> None:
        self._write_json("history.json", [asdict(item) for item in self.history])

    def set_receive_dir(self, path: Path) -> None:
        path.mkdir(parents=True, exist_ok=True)
        with self.lock:
            self.receive_dir = path
            self._write_json("settings.json", {"receive_dir": str(path)})
        self.emit("settings")

    def emit(self, event: str) -> None:
        if self.callback:
            self.callback(event)

    def pair(self, code: str, device: str) -> str | None:
        with self.lock:
            if not secrets.compare_digest(str(code), self.pairing_code):
                return None
            token = secrets.token_urlsafe(32)
            self.tokens[token] = (device or "Android 手机")[:80]
            self.pairing_code = self._new_code()
        self.emit("paired")
        return token

    def device_for(self, token: str) -> str | None:
        with self.lock:
            return self.tokens.get(token)

    def connected_devices(self) -> list[str]:
        with self.lock:
            return list(dict.fromkeys(self.tokens.values()))

    def disconnect(self, token: str | None = None) -> None:
        with self.lock:
            if token:
                self.tokens.pop(token, None)
            else:
                self.tokens.clear()
        self.emit("disconnected")

    def add_shared(self, paths: list[Path]) -> list[SharedFile]:
        added: list[SharedFile] = []
        with self.lock:
            for path in paths:
                if path.is_file():
                    item = SharedFile(uuid.uuid4().hex, path.name, path.stat().st_size, str(path))
                    self.shared[item.id] = item
                    added.append(item)
        if added:
            self.emit("shared")
        return added

    def remove_shared(self, ids: list[str]) -> None:
        with self.lock:
            for file_id in ids:
                self.shared.pop(file_id, None)
        self.emit("shared")

    def clear_shared(self) -> None:
        with self.lock:
            self.shared.clear()
        self.emit("shared")

    def list_shared(self) -> list[dict[str, object]]:
        with self.lock:
            missing = [key for key, item in self.shared.items() if not Path(item.path).is_file()]
            for key in missing:
                self.shared.pop(key, None)
            return [item.public() for item in self.shared.values()]

    def get_shared(self, file_id: str) -> SharedFile | None:
        with self.lock:
            item = self.shared.get(file_id)
            return item if item and Path(item.path).is_file() else None

    def mark_downloaded(self, file_id: str) -> None:
        with self.lock:
            item = self.shared.get(file_id)
            if item:
                item.downloads += 1
                item.status = "已发送到手机"
        self.emit("shared")

    def add_history(self, record: TransferRecord) -> None:
        with self.lock:
            self.history.insert(0, record)
            del self.history[100:]
            self._save_history()
        self.emit("history")

    def clear_history(self) -> None:
        with self.lock:
            self.history.clear()
            self._save_history()
        self.emit("history")

    def public_history(self) -> list[dict[str, object]]:
        with self.lock:
            return [asdict(item) for item in self.history]


class DroidLinkServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], state: AppState):
        self.state = state
        super().__init__(address, DroidLinkHandler)


class DroidLinkHandler(BaseHTTPRequestHandler):
    server: DroidLinkServer
    protocol_version = "HTTP/1.1"

    def log_message(self, _format: str, *_args: object) -> None:
        return

    def _json(self, status: int, payload: dict[str, object]) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _token(self) -> str:
        auth = self.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            return auth[7:]
        return urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get("token", [""])[0]

    def _authorized(self) -> str | None:
        return self.server.state.device_for(self._token())

    def _read_json(self) -> dict[str, object]:
        try:
            length = min(int(self.headers.get("Content-Length", "0") or 0), 65_536)
        except ValueError:
            length = 0
        try:
            return json.loads(self.rfile.read(length) or b"{}")
        except (json.JSONDecodeError, UnicodeDecodeError):
            return {}

    def do_GET(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlsplit(self.path)
        if parsed.path == "/":
            body = mobile_page()
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        if parsed.path == "/api/ping":
            self._json(200, {"ok": True, "computer": socket.gethostname(), "version": "0.2.0"})
            return
        device = self._authorized()
        if not device:
            self._json(401, {"error": "授权已失效，请重新配对"})
            return
        if parsed.path == "/api/session":
            self._json(200, {"device": device, "computer": socket.gethostname(), "connection": "Wi-Fi 局域网"})
            return
        if parsed.path == "/api/files":
            self._json(200, {"files": self.server.state.list_shared()})
            return
        if parsed.path == "/api/history":
            self._json(200, {"history": self.server.state.public_history()})
            return
        if parsed.path.startswith("/api/download/"):
            self._download(parsed.path.rsplit("/", 1)[-1], device)
            return
        self._json(404, {"error": "接口不存在"})

    def do_POST(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlsplit(self.path)
        if parsed.path == "/api/pair":
            data = self._read_json()
            token = self.server.state.pair(str(data.get("code", "")), str(data.get("device", "Android 手机")))
            if not token:
                self._json(403, {"error": "配对码不正确或已更新"})
            else:
                self._json(200, {"token": token, "computer": socket.gethostname(), "connection": "Wi-Fi 局域网"})
            return
        device = self._authorized()
        if not device:
            self._json(401, {"error": "授权已失效，请重新配对"})
            return
        if parsed.path == "/api/upload":
            self._upload(device)
            return
        if parsed.path == "/api/disconnect":
            self.server.state.disconnect(self._token())
            self._json(200, {"ok": True})
            return
        self._json(404, {"error": "接口不存在"})

    def _upload(self, device: str) -> None:
        try:
            length = int(self.headers.get("Content-Length", "-1"))
        except ValueError:
            length = -1
        if length < 0 or length > MAX_UPLOAD_BYTES:
            self._json(413, {"error": "文件大小无效或超过 10GB 限制"})
            return
        raw_name = urllib.parse.unquote(self.headers.get("X-File-Name", ""))
        target = unique_path(self.server.state.receive_dir, raw_name)
        partial = target.with_name(target.name + ".part")
        remaining = length
        try:
            with partial.open("wb") as output:
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ConnectionError("文件传输提前中断")
                    output.write(chunk)
                    remaining -= len(chunk)
            partial.replace(target)
        except Exception as exc:
            partial.unlink(missing_ok=True)
            self.server.state.add_history(TransferRecord(target.name, length, "手机 → 电脑", human_time(), str(target), "失败", str(exc)))
            self._json(500, {"error": f"保存失败：{exc}"})
            return
        self.server.state.add_history(TransferRecord(target.name, length, "手机 → 电脑", human_time(), str(target)))
        self._json(200, {"ok": True, "name": target.name, "device": device})

    def _download(self, file_id: str, device: str) -> None:
        item = self.server.state.get_shared(file_id)
        if not item:
            self._json(404, {"error": "文件不存在或已被移动"})
            return
        path = Path(item.path)
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        encoded = urllib.parse.quote(path.name)
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(path.stat().st_size))
        self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{encoded}")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            with path.open("rb") as source:
                while chunk := source.read(1024 * 1024):
                    self.wfile.write(chunk)
        except (ConnectionError, BrokenPipeError) as exc:
            self.server.state.add_history(TransferRecord(path.name, path.stat().st_size, "电脑 → 手机", human_time(), str(path), "已取消", str(exc)))
            return
        self.server.state.mark_downloaded(file_id)
        self.server.state.add_history(TransferRecord(path.name, path.stat().st_size, "电脑 → 手机", human_time(), str(path)))


def start_server(state: AppState, first_port: int = 8765) -> tuple[DroidLinkServer, threading.Thread]:
    error: OSError | None = None
    for port in range(first_port, first_port + 20):
        try:
            server = DroidLinkServer(("0.0.0.0", port), state)
            thread = threading.Thread(target=server.serve_forever, name="DroidLinkServer", daemon=True)
            thread.start()
            return server, thread
        except OSError as exc:
            error = exc
    raise OSError("8765-8784 端口均不可用") from error
