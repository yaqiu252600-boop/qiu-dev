# DroidLink currently ships without code shrinking.
