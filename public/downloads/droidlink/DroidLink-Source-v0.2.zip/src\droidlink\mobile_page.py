from __future__ import annotations


def mobile_page() -> bytes:
    return _HTML.encode("utf-8")


_HTML = r"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="theme-color" content="#2563eb">
  <title>DroidLink 本地互传</title>
  <style>
    :root{--blue:#2563eb;--blue2:#1d4ed8;--ink:#172033;--muted:#64748b;--line:#e2e8f0;--bg:#f4f7fb;--ok:#0f9f6e;--bad:#dc2626}
    *{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif}
    .wrap{max-width:720px;margin:auto;padding:18px 16px 48px}.hero{padding:20px 4px 12px}.brand{font-size:25px;font-weight:800;letter-spacing:-.5px}.sub{color:var(--muted);font-size:14px;margin-top:5px}
    .card{background:#fff;border:1px solid var(--line);border-radius:20px;padding:18px;margin-top:14px;box-shadow:0 8px 24px rgba(30,64,175,.06)}
    h2{font-size:18px;margin:0 0 14px}.label{font-size:13px;color:var(--muted);margin:12px 0 6px}.row{display:flex;gap:10px;align-items:center}.row>*{min-width:0}
    input[type=text],input[type=number]{width:100%;border:1px solid #cbd5e1;border-radius:12px;padding:13px 14px;font-size:16px;outline:none}input:focus{border-color:var(--blue);box-shadow:0 0 0 3px #dbeafe}
    button,.button{border:0;border-radius:12px;padding:12px 15px;font-size:15px;font-weight:700;cursor:pointer;text-decoration:none;text-align:center;display:inline-block}
    .primary{background:var(--blue);color:#fff}.primary:active{background:var(--blue2)}.secondary{background:#eff6ff;color:var(--blue)}.ghost{background:#f1f5f9;color:#334155}.danger{background:#fef2f2;color:var(--bad)}.wide{width:100%}
    .status{display:flex;align-items:center;gap:8px;font-size:14px;color:var(--muted)}.dot{width:9px;height:9px;border-radius:50%;background:#94a3b8}.dot.ok{background:var(--ok)}
    .hidden{display:none!important}.drop{border:1.5px dashed #93c5fd;background:#f8fbff;border-radius:16px;padding:20px;text-align:center}.drop strong{display:block;font-size:17px}.drop span{display:block;color:var(--muted);font-size:13px;margin:6px 0 14px}
    .progress{height:8px;background:#e2e8f0;border-radius:99px;overflow:hidden;margin-top:12px}.bar{height:100%;width:0;background:linear-gradient(90deg,#2563eb,#38bdf8);transition:width .15s}.progress-text{font-size:13px;color:var(--muted);margin:7px 0}
    .file{display:flex;gap:10px;align-items:center;padding:12px 0;border-top:1px solid #eef2f7}.file:first-child{border-top:0}.file-main{flex:1;min-width:0}.file-name{font-weight:650;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.file-meta{font-size:12px;color:var(--muted);margin-top:3px}
    .tag{font-size:11px;color:#0f766e;background:#ecfdf5;padding:3px 7px;border-radius:99px}.empty{padding:18px 0;color:var(--muted);font-size:14px;text-align:center}.notice{font-size:13px;color:var(--muted);line-height:1.55}.toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:#172033;color:#fff;padding:11px 16px;border-radius:12px;font-size:14px;opacity:0;pointer-events:none;transition:.2s;max-width:88%;z-index:10}.toast.show{opacity:1}
  </style>
</head>
<body><main class="wrap">
  <header class="hero"><div class="brand">DroidLink 本地互传</div><div class="sub">文件只在当前局域网内传输，不经过云端</div></header>

  <section id="pairCard" class="card">
    <h2>连接这台电脑</h2>
    <div class="label">配对码</div><input id="code" type="number" inputmode="numeric" maxlength="6" placeholder="输入电脑端的 6 位数字">
    <div class="label">手机名称</div><input id="device" type="text" maxlength="40" value="Android 手机">
    <button id="pairBtn" class="primary wide" style="margin-top:16px">安全连接</button>
    <p class="notice">配对码只能使用一次。连接后手机可以随时主动断开。</p>
  </section>

  <div id="app" class="hidden">
    <section class="card"><div class="row"><div class="status" style="flex:1"><span class="dot ok"></span><span id="connectedText">Wi-Fi 已连接</span></div><button id="disconnect" class="ghost">断开</button></div></section>
    <section class="card">
      <h2>发送到电脑</h2>
      <div class="drop"><strong>选择手机文件</strong><span>支持多选、大文件、取消和失败重试</span><input id="picker" type="file" multiple class="hidden"><button id="pickBtn" class="primary">选择文件</button></div>
      <div id="uploadProgress" class="hidden"><div class="progress"><div id="uploadBar" class="bar"></div></div><div id="uploadText" class="progress-text"></div><div class="row"><button id="cancelUpload" class="danger">取消传输</button><button id="retryUpload" class="secondary hidden">重试失败文件</button></div></div>
    </section>
    <section class="card"><div class="row"><h2 style="flex:1">电脑发来的文件</h2><button id="refresh" class="secondary">刷新</button></div><div id="files"><div class="empty">电脑端还没有选择文件</div></div></section>
    <section class="card"><h2>最近记录</h2><div id="history"><div class="empty">暂无传输记录</div></div></section>
  </div>
</main><div id="toast" class="toast"></div>
<script>
const $=s=>document.querySelector(s), params=new URLSearchParams(location.search);
let token=localStorage.getItem('droidlink_token')||'', currentRequest=null, failedFiles=[];
$('#code').value=params.get('code')||'';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const size=n=>{if(n<1024)return n+' B';if(n<1048576)return(n/1024).toFixed(1)+' KB';if(n<1073741824)return(n/1048576).toFixed(1)+' MB';return(n/1073741824).toFixed(2)+' GB'};
const duration=s=>s<60?Math.ceil(s)+' 秒':Math.ceil(s/60)+' 分钟';
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2500)}
function setConnected(ok,text='Wi-Fi 已连接'){ $('#pairCard').classList.toggle('hidden',ok);$('#app').classList.toggle('hidden',!ok);if(ok)$('#connectedText').textContent=text; }
async function api(path,opts={}){opts.headers=Object.assign({},opts.headers||{},token?{'Authorization':'Bearer '+token}:{});const r=await fetch(path,opts);if(r.status===401){clearSession();throw Error('授权已失效，请重新配对')}const data=await r.json();if(!r.ok)throw Error(data.error||'请求失败');return data}
function clearSession(){token='';localStorage.removeItem('droidlink_token');setConnected(false)}
async function pair(){try{const code=String($('#code').value).trim(),device=$('#device').value.trim()||'Android 手机';if(code.length!==6)throw Error('请输入 6 位配对码');const d=await api('/api/pair',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code,device})});token=d.token;localStorage.setItem('droidlink_token',token);localStorage.setItem('droidlink_device',device);setConnected(true,`${d.computer} · ${d.connection}`);await refresh();toast('连接成功')}catch(e){toast(e.message)}}
async function refresh(){try{const [s,f,h]=await Promise.all([api('/api/session'),api('/api/files'),api('/api/history')]);setConnected(true,`${s.computer} · ${s.connection}`);renderFiles(f.files);renderHistory(h.history)}catch(e){toast(e.message)}}
function renderFiles(files){$('#files').innerHTML=files.length?files.map(f=>`<div class="file"><div class="file-main"><div class="file-name">${esc(f.name)}</div><div class="file-meta">${size(f.size)} · ${esc(f.status)}</div></div><a class="button secondary" href="/api/download/${encodeURIComponent(f.id)}?token=${encodeURIComponent(token)}">下载</a></div>`).join(''):'<div class="empty">电脑端还没有选择文件</div>'}
function renderHistory(items){$('#history').innerHTML=items.length?items.slice(0,8).map(x=>`<div class="file"><div class="file-main"><div class="file-name">${x.direction==='手机 → 电脑'?'↑':'↓'} ${esc(x.name)}</div><div class="file-meta">${esc(x.direction)} · ${size(x.size)} · ${esc(x.time)}</div></div><span class="tag">${esc(x.status||'成功')}</span></div>`).join(''):'<div class="empty">暂无传输记录</div>'}
function sendOne(file,index,total){return new Promise((resolve,reject)=>{const x=new XMLHttpRequest();currentRequest=x;const started=Date.now();x.open('POST','/api/upload');x.setRequestHeader('Authorization','Bearer '+token);x.setRequestHeader('X-File-Name',encodeURIComponent(file.name));x.upload.onprogress=e=>{if(e.lengthComputable){const p=Math.round(e.loaded/e.total*100),seconds=Math.max((Date.now()-started)/1000,.1),speed=e.loaded/seconds,eta=speed?Math.max((e.total-e.loaded)/speed,0):0;$('#uploadBar').style.width=p+'%';$('#uploadText').textContent=`${index+1}/${total}  ${file.name}  ${p}% · ${size(speed)}/s · 剩余 ${duration(eta)}`}};x.onload=()=>{currentRequest=null;if(x.status>=200&&x.status<300)resolve();else{let msg='上传失败';try{msg=JSON.parse(x.responseText||'{}').error||msg}catch{}reject(Error(msg))}};x.onerror=()=>{currentRequest=null;reject(Error('网络连接中断'))};x.onabort=()=>{currentRequest=null;reject(Error('传输已取消'))};x.send(file)})}
async function upload(files){if(!files.length)return;failedFiles=[];$('#retryUpload').classList.add('hidden');$('#uploadProgress').classList.remove('hidden');try{for(let i=0;i<files.length;i++){try{await sendOne(files[i],i,files.length)}catch(e){failedFiles=files.slice(i);throw e}}toast('已发送到电脑');await refresh()}catch(e){toast(e.message);if(failedFiles.length)$('#retryUpload').classList.remove('hidden')}finally{if(!failedFiles.length)setTimeout(()=>{$('#uploadProgress').classList.add('hidden');$('#uploadBar').style.width='0'},900)}}
async function disconnect(){try{await api('/api/disconnect',{method:'POST'})}catch{}clearSession();toast('已断开连接')}
$('#pairBtn').onclick=pair;$('#pickBtn').onclick=()=>$('#picker').click();$('#picker').onchange=e=>upload([...e.target.files]);$('#refresh').onclick=refresh;$('#disconnect').onclick=disconnect;$('#cancelUpload').onclick=()=>{if(currentRequest)currentRequest.abort()};$('#retryUpload').onclick=()=>upload(failedFiles);
if(token){setConnected(true);refresh()}else setConnected(false);
setInterval(()=>{if(token)refresh()},6000);
</script></body></html>"""
