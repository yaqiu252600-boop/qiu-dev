from __future__ import annotations

import os
import queue
import shutil
import tkinter as tk
import webbrowser
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import qrcode
from PIL import ImageTk

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
except ImportError:  # pragma: no cover - development fallback
    DND_FILES = "DND_Files"
    TkinterDnD = None

from .core import AppState, default_data_dir, local_ipv4, start_server


BG = "#f3f6fb"
CARD = "#ffffff"
INK = "#162033"
MUTED = "#64748b"
BLUE = "#2563eb"


def human_size(value: int) -> str:
    size = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return str(value)


class DroidLinkApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.events: queue.Queue[str] = queue.Queue()
        self.data_dir = default_data_dir()
        self.state = AppState(Path.home() / "Downloads" / "DroidLink", self.data_dir)
        self.state.callback = self.events.put
        self.server, self.server_thread = start_server(self.state)
        self.ip = local_ipv4()
        self.address = f"http://{self.ip}:{self.server.server_port}"
        self.qr_photo: ImageTk.PhotoImage | None = None
        self._configure_window()
        self._configure_style()
        self._build_ui()
        self._enable_drop()
        self._refresh_all()
        self.root.after(250, self._poll_events)
        self.root.protocol("WM_DELETE_WINDOW", self._close)

    def _configure_window(self) -> None:
        self.root.title("DroidLink 本地互传")
        self.root.geometry("1120x760")
        self.root.minsize(940, 650)
        self.root.configure(bg=BG)

    def _configure_style(self) -> None:
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("Treeview", background=CARD, fieldbackground=CARD, foreground=INK, rowheight=34, borderwidth=0, font=("Microsoft YaHei UI", 10))
        style.configure("Treeview.Heading", background="#eef3f9", foreground=MUTED, relief="flat", font=("Microsoft YaHei UI", 9, "bold"))
        style.map("Treeview", background=[("selected", "#dbeafe")], foreground=[("selected", INK)])

    def _label(self, parent: tk.Widget, text: str, size: int = 10, color: str = INK, bold: bool = False, **kwargs: object) -> tk.Label:
        return tk.Label(parent, text=text, bg=kwargs.pop("bg", CARD), fg=color, font=("Microsoft YaHei UI", size, "bold" if bold else "normal"), **kwargs)

    def _button(self, parent: tk.Widget, text: str, command, primary: bool = False, compact: bool = False) -> tk.Button:
        return tk.Button(parent, text=text, command=command, bg=BLUE if primary else "#eef4ff", fg="white" if primary else BLUE, activebackground="#1d4ed8" if primary else "#dbeafe", activeforeground="white" if primary else BLUE, relief="flat", bd=0, padx=12 if compact else 18, pady=7 if compact else 10, cursor="hand2", font=("Microsoft YaHei UI", 9 if compact else 10, "bold"))

    def _card(self, parent: tk.Widget) -> tk.Frame:
        return tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground="#e2e8f0", padx=18, pady=16)

    def _build_ui(self) -> None:
        outer = tk.Frame(self.root, bg=BG, padx=24, pady=20)
        outer.pack(fill="both", expand=True)
        header = tk.Frame(outer, bg=BG)
        header.pack(fill="x", pady=(0, 16))
        self._label(header, "DroidLink", 23, INK, True, bg=BG).pack(side="left")
        self._label(header, "Android ↔ Windows 本地互联", 10, MUTED, bg=BG).pack(side="left", padx=14, pady=(8, 0))
        self.status_label = self._label(header, "● 服务已启动 · 等待手机连接", 10, "#0f9f6e", True, bg=BG)
        self.status_label.pack(side="right", pady=(7, 0))

        body = tk.Frame(outer, bg=BG)
        body.pack(fill="both", expand=True)
        left = tk.Frame(body, bg=BG, width=330)
        left.pack(side="left", fill="y", padx=(0, 16))
        left.pack_propagate(False)
        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="both", expand=True)

        connect = self._card(left)
        connect.pack(fill="x")
        self._label(connect, "手机扫码连接", 15, INK, True).pack(anchor="w")
        self._label(connect, "手机和电脑需连接同一个 Wi-Fi", 9, MUTED).pack(anchor="w", pady=(3, 10))
        self.qr_label = tk.Label(connect, bg=CARD)
        self.qr_label.pack(pady=2)
        self.code_label = self._label(connect, "", 21, BLUE, True)
        self.code_label.pack()
        self._label(connect, "6 位一次性配对码", 9, MUTED).pack(pady=(1, 8))
        self.address_label = self._label(connect, self.address, 9, MUTED)
        self.address_label.pack()
        button_row = tk.Frame(connect, bg=CARD)
        button_row.pack(fill="x", pady=(10, 0))
        self._button(button_row, "复制地址", self._copy_address, compact=True).pack(side="left", fill="x", expand=True, padx=(0, 4))
        self._button(button_row, "浏览器测试", lambda: webbrowser.open(self._pair_url()), compact=True).pack(side="left", fill="x", expand=True, padx=4)
        self._button(button_row, "断开手机", self._disconnect_all, compact=True).pack(side="left", fill="x", expand=True, padx=(4, 0))

        folder = self._card(left)
        folder.pack(fill="x", pady=(16, 0))
        self._label(folder, "手机文件保存到", 12, INK, True).pack(anchor="w")
        self.folder_label = self._label(folder, str(self.state.receive_dir), 9, MUTED, wraplength=275, justify="left")
        self.folder_label.pack(anchor="w", pady=(6, 10))
        row = tk.Frame(folder, bg=CARD)
        row.pack(fill="x")
        self._button(row, "打开文件夹", self._open_receive, compact=True).pack(side="left", fill="x", expand=True, padx=(0, 5))
        self._button(row, "更改目录", self._choose_receive_dir, compact=True).pack(side="left", fill="x", expand=True, padx=(5, 0))
        self._label(folder, "保存目录和传输历史会自动记住。文件不经过云端。", 9, "#0f766e", wraplength=275, justify="left").pack(anchor="w", pady=(12, 0))

        send = self._card(right)
        send.pack(fill="both", expand=True)
        send_top = tk.Frame(send, bg=CARD)
        send_top.pack(fill="x")
        title_wrap = tk.Frame(send_top, bg=CARD)
        title_wrap.pack(side="left")
        self._label(title_wrap, "发送到手机", 15, INK, True).pack(anchor="w")
        self._label(title_wrap, "可选择文件、压缩发送文件夹，或直接拖到此窗口", 9, MUTED).pack(anchor="w", pady=(3, 0))
        self._button(send_top, "选择文件夹", self._choose_folder, compact=True).pack(side="right", padx=(8, 0))
        self._button(send_top, "＋ 选择文件", self._choose_files, True, compact=True).pack(side="right")

        self.drop_label = self._label(send, "把文件或文件夹拖到这里", 10, BLUE, True, bg="#f8fbff", pady=10, relief="solid", bd=1)
        self.drop_label.pack(fill="x", pady=(12, 8))
        self.shared_tree = ttk.Treeview(send, columns=("name", "size", "status"), show="headings", height=6, selectmode="extended")
        for key, text, width, anchor in (("name", "文件名", 400, "w"), ("size", "大小", 95, "center"), ("status", "状态", 125, "center")):
            self.shared_tree.heading(key, text=text)
            self.shared_tree.column(key, width=width, anchor=anchor)
        self.shared_tree.pack(fill="both", expand=True)
        send_actions = tk.Frame(send, bg=CARD)
        send_actions.pack(fill="x", pady=(8, 0))
        self._button(send_actions, "移除选中", self._remove_selected, compact=True).pack(side="right")
        self._button(send_actions, "清空列表", self.state.clear_shared, compact=True).pack(side="right", padx=(0, 8))

        history = self._card(right)
        history.pack(fill="both", expand=True, pady=(16, 0))
        history_top = tk.Frame(history, bg=CARD)
        history_top.pack(fill="x")
        self._label(history_top, "传输记录", 15, INK, True).pack(side="left")
        self._button(history_top, "清空记录", self._clear_history, compact=True).pack(side="right")
        self.history_tree = ttk.Treeview(history, columns=("direction", "name", "size", "time", "status"), show="headings", height=7)
        for key, text, width, anchor in (("direction", "方向", 105, "center"), ("name", "文件名", 280, "w"), ("size", "大小", 85, "center"), ("time", "时间", 145, "center"), ("status", "状态", 70, "center")):
            self.history_tree.heading(key, text=text)
            self.history_tree.column(key, width=width, anchor=anchor)
        self.history_tree.pack(fill="both", expand=True, pady=(12, 0))
        self.history_tree.bind("<Double-1>", self._history_open)

    def _enable_drop(self) -> None:
        if not hasattr(self.root, "drop_target_register"):
            self.drop_label.configure(text="拖拽组件不可用，可使用“选择文件”", fg=MUTED)
            return
        self.root.drop_target_register(DND_FILES)  # type: ignore[attr-defined]
        self.root.dnd_bind("<<Drop>>", self._on_drop)  # type: ignore[attr-defined]

    def _on_drop(self, event) -> None:
        paths = [Path(value) for value in self.root.tk.splitlist(event.data)]
        self._share_paths(paths)

    def _pair_url(self) -> str:
        return f"{self.address}/?code={self.state.pairing_code}"

    def _update_qr(self) -> None:
        image = qrcode.make(self._pair_url()).resize((176, 176))
        self.qr_photo = ImageTk.PhotoImage(image)
        self.qr_label.configure(image=self.qr_photo)
        self.code_label.configure(text="  ".join(self.state.pairing_code))

    def _copy_address(self) -> None:
        self.root.clipboard_clear()
        self.root.clipboard_append(self._pair_url())
        self._flash_status("✓ 连接地址已复制")

    def _flash_status(self, text: str) -> None:
        self.status_label.configure(text=text)
        self.root.after(1800, self._refresh_connection_status)

    def _choose_files(self) -> None:
        values = filedialog.askopenfilenames(title="选择要发送到手机的文件")
        if values:
            self._share_paths([Path(value) for value in values])

    def _choose_folder(self) -> None:
        value = filedialog.askdirectory(title="选择要发送到手机的文件夹")
        if value:
            self._share_paths([Path(value)])

    def _share_paths(self, paths: list[Path]) -> None:
        files: list[Path] = []
        staging = self.data_dir / "staging"
        staging.mkdir(parents=True, exist_ok=True)
        for path in paths:
            if path.is_file():
                files.append(path)
            elif path.is_dir():
                stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
                base = staging / f"{path.name}-{stamp}"
                try:
                    archive = Path(shutil.make_archive(str(base), "zip", root_dir=path.parent, base_dir=path.name))
                    files.append(archive)
                except (OSError, shutil.Error) as exc:
                    messagebox.showerror("文件夹发送失败", str(exc))
        added = self.state.add_shared(files)
        if added:
            self._flash_status(f"✓ 已加入 {len(added)} 个发送任务")

    def _remove_selected(self) -> None:
        selected = list(self.shared_tree.selection())
        if selected:
            self.state.remove_shared(selected)

    def _choose_receive_dir(self) -> None:
        value = filedialog.askdirectory(title="选择手机文件接收目录", initialdir=str(self.state.receive_dir))
        if value:
            self.state.set_receive_dir(Path(value))
            self.folder_label.configure(text=str(self.state.receive_dir))

    def _open_receive(self) -> None:
        self.state.receive_dir.mkdir(parents=True, exist_ok=True)
        os.startfile(self.state.receive_dir)  # type: ignore[attr-defined]

    def _disconnect_all(self) -> None:
        if self.state.connected_devices():
            self.state.disconnect()
            self._flash_status("手机已断开")

    def _clear_history(self) -> None:
        if self.state.history and messagebox.askyesno("清空传输记录", "确定清空全部传输记录吗？文件本身不会被删除。"):
            self.state.clear_history()

    def _history_open(self, _event=None) -> None:
        selected = self.history_tree.selection()
        if not selected:
            return
        index = int(selected[0])
        with self.state.lock:
            if index >= len(self.state.history):
                return
            path = Path(self.state.history[index].path)
        if path.exists():
            os.startfile(path.parent)  # type: ignore[attr-defined]
        else:
            messagebox.showwarning("文件不存在", "文件已被移动或删除。")

    def _refresh_connection_status(self) -> None:
        devices = self.state.connected_devices()
        if devices:
            self.status_label.configure(text=f"● Wi-Fi 已连接 · {devices[0]}", fg="#0f9f6e")
        else:
            self.status_label.configure(text="● 服务已启动 · 等待手机连接", fg="#0f9f6e")

    def _refresh_all(self) -> None:
        self._update_qr()
        self._refresh_connection_status()
        for item in self.shared_tree.get_children():
            self.shared_tree.delete(item)
        for item in self.state.list_shared():
            self.shared_tree.insert("", "end", iid=str(item["id"]), values=(item["name"], human_size(int(item["size"])), item["status"]))
        for item in self.history_tree.get_children():
            self.history_tree.delete(item)
        for index, item in enumerate(self.state.public_history()):
            self.history_tree.insert("", "end", iid=str(index), values=(item["direction"], item["name"], human_size(int(item["size"])), item["time"], item["status"]))

    def _poll_events(self) -> None:
        changed = False
        try:
            while True:
                self.events.get_nowait()
                changed = True
        except queue.Empty:
            pass
        if changed:
            self._refresh_all()
        self.root.after(250, self._poll_events)

    def _close(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.root.destroy()


def run() -> None:
    root = TkinterDnD.Tk() if TkinterDnD else tk.Tk()
    try:
        DroidLinkApp(root)
    except OSError as exc:
        messagebox.showerror("DroidLink 无法启动", str(exc))
        root.destroy()
        return
    root.mainloop()
